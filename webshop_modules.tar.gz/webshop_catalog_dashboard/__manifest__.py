{
    'name': 'Webshop Catalog Dashboard',
    'version': '19.0.1.0.0',
    'category': 'Website',
    'summary': 'Dashboard voor webshop product-validatie',
    'description': """
Klikbaar dashboard met tegels voor producten die wachten op publicatie.
    """,
    'author': 'Sybdeb',
    'depends': ['website_sale'],
    'data': [
        'security/ir.model.access.csv',
        'views/dashboard_views.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
    'license': 'LGPL-3',  # Free version - marketing tool
}
